package GalaleloPart1;

import javax.swing.JOptionPane;

public class Login {
    
    String passwordMessage;
    String nameMessage;
   
    /*This method returns true if the username contains an underscore and is not longer than 5 letters and returns false otherwise*/
    public boolean checkUserName(String user_name){
        return user_name.contains("_") && user_name.length() <= 5;
    }

    /*This method returns true if the password is 8 characters long, contains an uppercase, a number and a special character and returns false otherwise*/
    public boolean checkPasswordComplexity(String password){
        
        boolean isPasswordOkay = false;
        boolean hasNumber = false;
        boolean hasCapitalLetter = false;
        boolean hasCharracter = false;
        char current;
        
        // the loop only executes if the password meets the length constraint
        if (password.length() >= 8){ 
            for (int i =0; i < password.length(); i++){
                current = password.charAt(i);

                if(Character.isDigit(current)){
                    hasNumber = true;
                }
                else if(Character.isUpperCase(current)){
                    hasCapitalLetter = true;
                }
                else if (!(Character.isLetterOrDigit(current))){
                    hasCharracter = true;
                }
            }
        }    
            
        if(hasNumber && hasCapitalLetter && hasCharracter){
            isPasswordOkay = true;
        }
        return isPasswordOkay;
        
    }

    /*
        This method returns messages that is determined by whether the password and username meet the entry requirements.
    */
    public String registerUser(String pass, String name){
        if (checkPasswordComplexity(pass)){
            passwordMessage = "Password successfully captured.";
        }
        else{
            passwordMessage = "Password not formatted correctly please ensure that your password contains at least 8 character long ,a capital letter ,a number and a special character.";
        }
        
        if (checkUserName(name)){
            nameMessage = "User name successfully captured.";
        }
        else{
            nameMessage = "Username is not correctly formatted, please ensure that your username contains an underscore and is no 5 characters in length";
        }
        
        return (nameMessage+ "\n" + passwordMessage);
    }

    
    public boolean loginUser(String pass, String usrname, boolean checkName, boolean checkPassword){
        
        boolean logged = false;
        if(checkName && checkPassword) { //only run in the user successfully registered
                      
            String username = JOptionPane.showInputDialog("Enter the username you used to register");
            
            String password = JOptionPane.showInputDialog("Enter the password you used to register");
            
            if (password.equals(pass) && username.equals(usrname)  ){
                logged = true;
            }
        }
        return logged;
    }
    
    
    public String returnLoginStatus(boolean regStatus, String name, String surname){
        String message;
        message = "Username or password incorrect, please try again";
        
        if (regStatus){
            message = "Welcome, " + name + " " + surname + ", it is great to see you again.";
        }
        return message;
    }
    // test data
    String usrname = "kyl_1";
    String passwrd = "Ch&&sec@ke99!";
}


