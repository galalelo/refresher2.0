
package GalaleloPart1;

import GalaleloPart1.Login;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.Test;

/**
 *
 * @author Galaletsang
 */
public class LoginTest {
    Login login = new Login();
    
    public LoginTest() {
    }

    @Test
    public void testCheckUserName() {
        String expected = "kyl_1";
        String actual = login.usrname;
        
        assertEquals(expected, actual);
    }

    @Test
    public void testCheckPasswordComplexity() {
        String expected = "Ch&&sec@ke99!";
        String actual = login.passwrd;
        
        assertEquals(expected, actual);
    }

    @Test
    public void testRegisterUser() {
    }

    @Test
    public void testLoginUser() {
    }

    @Test
    public void testReturnLoginStatus() {
    }
    
}
